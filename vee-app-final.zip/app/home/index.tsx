import { useRef, useState, useCallback } from 'react';
import {
  View, Text, ScrollView, Pressable,
  Dimensions, NativeScrollEvent, NativeSyntheticEvent, Alert, Platform,
} from 'react-native';
import { SafeAreaView, useSafeAreaInsets } from 'react-native-safe-area-context';
import { Feather } from '@expo/vector-icons';
import * as Haptics from 'expo-haptics';
import ScalePress from '@/components/ScalePress';
import VoiceRoomHome from '@/src/features/voice-room/screens/VoiceRoomHome';
import ProfileSection from '@/app/profile/index';
import ChatScreen from '@/app/chat/index';
import ContactsScreen from '@/src/features/contacts/ContactsScreen';
import GlobalSearchModal from '@/src/features/home/GlobalSearchModal';
import UserSearchModal from '@/src/features/user-search/UserSearchModal';
import InAppNotification from '@/src/features/chat/components/InAppNotification';
import MinimizedRoomBar from '@/src/features/voice-room/components/MinimizedRoomBar';
import { useRouter } from 'expo-router';
import { useTranslation } from 'react-i18next';
import { VeeUser } from '@/src/services/userService';

const { width } = Dimensions.get('window');

const C = {
  bg: '#07020F',
  primary: '#7C3AED',
  glow: '#8B5CF6',
  text: '#FFFFFF',
  muted: '#4A3D6E',
  mutedActive: '#B8A6D9',
  border: '#1E1830',
  surface: 'rgba(255,255,255,0.045)',
} as const;

/**
 * Section layout:
 *  0: Profile   ← swipe RIGHT from Chat, or tap profile icon
 *  1: Chat      ← default start
 *  2: Voice Room
 *  3: Contacts
 */
const TOTAL_SECTIONS = 4;
const DEFAULT_INDEX  = 1; // Chat

const TABS: {
  title: string;
  icon: React.ComponentProps<typeof Feather>['name'];
  sectionIndex: number;
}[] = [
  { title: 'Chat',       icon: 'message-circle', sectionIndex: 1 },
  { title: 'Voice Room', icon: 'mic',            sectionIndex: 2 },
  { title: 'Contacts',   icon: 'users',           sectionIndex: 3 },
];

// ─────────────────────────────────────────
// Top tab pill
// ─────────────────────────────────────────
function TopTab({
  title, icon, active, onPress,
}: {
  title: string;
  icon: React.ComponentProps<typeof Feather>['name'];
  active: boolean;
  onPress: () => void;
}) {
  return (
    <Pressable onPress={onPress} style={{ alignItems: 'center', paddingHorizontal: 10, paddingVertical: 4 }}>
      <Feather name={icon} size={22} color={active ? C.glow : C.muted} />
      <Text style={{
        color: active ? C.text : C.muted,
        fontSize: 11, fontWeight: active ? '800' : '400',
        marginTop: 3, letterSpacing: 0.2,
      }}>
        {title}
      </Text>
      <View style={{
        marginTop: 3,
        width: active ? 5 : 0, height: active ? 5 : 0,
        borderRadius: 3, backgroundColor: C.glow,
      }} />
    </Pressable>
  );
}

// ─────────────────────────────────────────
// Bottom nav
// ─────────────────────────────────────────
function BottomNav({
  activeIndex, onPress, onPlusPress,
}: {
  activeIndex: number;
  onPress: (sectionIndex: number) => void;
  onPlusPress: () => void;
}) {
  const insets   = useSafeAreaInsets();
  const bottomPad = Math.max(insets.bottom, Platform.OS === 'web' ? 34 : 0) + 8;

  const chatActive     = activeIndex === 1;
  const contactsActive = activeIndex === 3;

  return (
    <View style={{
      position: 'absolute', bottom: 0, left: 0, right: 0,
      paddingBottom: bottomPad, paddingTop: 10,
      backgroundColor: 'rgba(7,2,15,0.97)',
      borderTopWidth: 1, borderTopColor: C.border,
      flexDirection: 'row', alignItems: 'center', justifyContent: 'space-around',
    }}>
      <Pressable onPress={() => onPress(1)} style={{ alignItems: 'center', flex: 1 }}>
        <Feather name="message-circle" size={24} color={chatActive ? C.glow : C.muted} />
        <Text style={{ color: chatActive ? C.glow : C.muted, fontSize: 11, fontWeight: chatActive ? '800' : '400', marginTop: 3 }}>
          Chat
        </Text>
      </Pressable>

      <View style={{ flex: 1, alignItems: 'center' }}>
        <ScalePress
          onPress={onPlusPress}
          style={{ marginTop: -24 }}
        >
          <View style={{
            width: 58, height: 58, borderRadius: 29,
            backgroundColor: C.primary, alignItems: 'center', justifyContent: 'center',
            shadowColor: C.glow, shadowOpacity: 0.6,
            shadowRadius: 18, shadowOffset: { width: 0, height: 6 }, elevation: 14,
            borderWidth: 3, borderColor: '#07020F',
          }}>
            <Feather name="plus" size={28} color="#fff" />
          </View>
        </ScalePress>
      </View>

      <Pressable onPress={() => onPress(3)} style={{ alignItems: 'center', flex: 1 }}>
        <Feather name="users" size={24} color={contactsActive ? C.glow : C.muted} />
        <Text style={{ color: contactsActive ? C.glow : C.muted, fontSize: 11, fontWeight: contactsActive ? '800' : '400', marginTop: 3 }}>
          Contacts
        </Text>
      </Pressable>
    </View>
  );
}

// ─────────────────────────────────────────
// Main HomeScreen
// ─────────────────────────────────────────
export default function HomeScreen() {
  const router = useRouter();
  const { t } = useTranslation();
  const scrollRef      = useRef<ScrollView>(null);
  const activeIndexRef = useRef(DEFAULT_INDEX);
  const [activeIndex, setActiveIndex] = useState(DEFAULT_INDEX);

  // Modals
  const [searchOpen, setSearchOpen] = useState(false);
  const [newMsgOpen, setNewMsgOpen] = useState(false);

  // ── Parent-scroll enabled/disabled state ──────────────────────────────────
  const scrollEnabledRef = useRef(true);
  const [outerScrollEnabled, setOuterScrollEnabled] = useState(true);

  const lockParentScroll = useCallback(() => {
    if (scrollEnabledRef.current) {
      scrollEnabledRef.current = false;
      setOuterScrollEnabled(false);
    }
  }, []);

  const unlockParentScroll = useCallback(() => {
    if (!scrollEnabledRef.current) {
      scrollEnabledRef.current = true;
      setOuterScrollEnabled(true);
    }
  }, []);

  // ── Navigation helper ─────────────────────────────────────────────────────
  const goToSection = (i: number) => {
    scrollEnabledRef.current = true;
    setOuterScrollEnabled(true);

    if (i === activeIndexRef.current) return;
    Haptics.selectionAsync();
    activeIndexRef.current = i;
    setActiveIndex(i);
    scrollRef.current?.scrollTo({ x: width * i, animated: true });
  };

  // ── Scroll event handlers ─────────────────────────────────────────────────
  const applyOffset = (offsetX: number) => {
    const clamped = Math.max(0, Math.min(TOTAL_SECTIONS - 1, Math.round(offsetX / width)));
    scrollEnabledRef.current = true;
    setOuterScrollEnabled(true);
    if (clamped !== activeIndexRef.current) {
      activeIndexRef.current = clamped;
      setActiveIndex(clamped);
      Haptics.selectionAsync();
    }
  };

  const onMomentumScrollEnd = (e: NativeSyntheticEvent<NativeScrollEvent>) =>
    applyOffset(e.nativeEvent.contentOffset.x);

  const onScrollEndDrag = (e: NativeSyntheticEvent<NativeScrollEvent>) =>
    applyOffset(e.nativeEvent.contentOffset.x);

  // ── "+" button handler ────────────────────────────────────────────────────
  const handlePlusPress = useCallback(() => {
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
    Alert.alert(
      t('home.plusTitle'),
      '',
      [
        {
          text: t('home.plusVoiceRoom'),
          onPress: () => {
            Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
            goToSection(2);
          },
        },
        {
          text: t('home.plusMessage'),
          onPress: () => {
            Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
            setNewMsgOpen(true);
          },
        },
        { text: 'Cancel', style: 'cancel' },
      ],
    );
  }, []);

  // ── New message user selected ──────────────────────────────────────────────
  const handleUserSelected = useCallback((selectedUser: VeeUser, chatId: string) => {
    setNewMsgOpen(false);
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
    router.push(
      `/inbox/${chatId}?participantId=${encodeURIComponent(selectedUser.uid)}&participantName=${encodeURIComponent(selectedUser.name)}` as never,
    );
  }, [router]);

  // ─────────────────────────────────────────────────────────────────────────
  const topPad = Platform.OS === 'web' ? 67 : 0;

  return (
    <View style={{ flex: 1, backgroundColor: C.bg }}>
      <SafeAreaView style={{ flex: 1 }} edges={['top']}>
        <View style={{ flex: 1, paddingTop: topPad }}>

          {/* ── Top header bar ── */}
          <View style={{
            flexDirection: 'row', alignItems: 'center',
            paddingHorizontal: 16, paddingVertical: 8,
          }}>
            {/* Profile avatar */}
            <ScalePress onPress={() => goToSection(0)}>
              <View style={{
                width: 44, height: 44, borderRadius: 22,
                backgroundColor: activeIndex === 0
                  ? 'rgba(139,92,246,0.28)'
                  : 'rgba(139,92,246,0.18)',
                borderWidth: 2,
                borderColor: activeIndex === 0 ? C.primary : C.glow,
                alignItems: 'center', justifyContent: 'center',
              }}>
                <Feather name="user" size={20} color={C.glow} />
              </View>
            </ScalePress>

            {/* Section tabs */}
            <View style={{
              flex: 1, flexDirection: 'row',
              justifyContent: 'space-evenly', marginHorizontal: 8,
            }}>
              {TABS.map((tab) => (
                <TopTab
                  key={tab.title}
                  title={tab.title}
                  icon={tab.icon}
                  active={activeIndex === tab.sectionIndex}
                  onPress={() => goToSection(tab.sectionIndex)}
                />
              ))}
            </View>

            {/* Search */}
            <ScalePress onPress={() => setSearchOpen(true)}>
              <View style={{
                width: 42, height: 42, borderRadius: 21,
                backgroundColor: C.surface,
                borderWidth: 1, borderColor: C.border,
                alignItems: 'center', justifyContent: 'center',
              }}>
                <Feather name="search" size={20} color={C.mutedActive} />
              </View>
            </ScalePress>
          </View>

          {/* ── Horizontal pager ── */}
          <ScrollView
            ref={scrollRef}
            horizontal
            snapToInterval={width}
            snapToAlignment="start"
            decelerationRate="fast"
            disableIntervalMomentum
            bounces={false}
            showsHorizontalScrollIndicator={false}
            scrollEventThrottle={16}
            scrollEnabled={outerScrollEnabled}
            contentOffset={{ x: width * DEFAULT_INDEX, y: 0 }}
            onMomentumScrollEnd={onMomentumScrollEnd}
            onScrollEndDrag={onScrollEndDrag}
            style={{ flex: 1 }}
          >
            {/* 0: Profile */}
            <View style={{ width, flex: 1 }}>
              <ProfileSection onNavigateToContacts={() => goToSection(3)} />
            </View>

            {/* 1: Chat */}
            <View style={{ width, flex: 1 }}>
              <ChatScreen />
            </View>

            {/* 2: Voice Room */}
            <View style={{ width, flex: 1, paddingHorizontal: 20 }}>
              <VoiceRoomHome
                onLockParentScroll={lockParentScroll}
                onUnlockParentScroll={unlockParentScroll}
              />
            </View>

            {/* 3: Contacts — Real implementation */}
            <View style={{ width, flex: 1 }}>
              <ContactsScreen />
            </View>
          </ScrollView>

          {/* Bottom nav — hidden on Profile screen */}
          {activeIndex !== 0 && (
            <BottomNav
              activeIndex={activeIndex}
              onPress={goToSection}
              onPlusPress={handlePlusPress}
            />
          )}
        </View>
      </SafeAreaView>

      {/* Global in-app notification banner */}
      <InAppNotification />

      {/* Minimized voice room floating bar */}
      <MinimizedRoomBar />

      {/* Global Search Modal */}
      <GlobalSearchModal
        visible={searchOpen}
        onClose={() => setSearchOpen(false)}
      />

      {/* New Message modal (UserSearch) */}
      <UserSearchModal
        visible={newMsgOpen}
        onClose={() => setNewMsgOpen(false)}
        onSelectUser={handleUserSelected}
      />
    </View>
  );
}

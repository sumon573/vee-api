import React, { useEffect } from 'react';
import { View, ActivityIndicator } from 'react-native';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { GestureHandlerRootView } from 'react-native-gesture-handler';
import { SafeAreaProvider } from 'react-native-safe-area-context';
import { I18nextProvider } from 'react-i18next';
import { ErrorBoundary } from '@/components/ErrorBoundary';
import {
  Inter_400Regular,
  Inter_500Medium,
  Inter_600SemiBold,
  Inter_700Bold,
  useFonts,
} from '@expo-google-fonts/inter';
import { Stack, useRouter, useSegments } from 'expo-router';
import * as SplashScreen from 'expo-splash-screen';
import { StatusBar } from 'expo-status-bar';
import { AuthProvider, useAuth } from '@/src/context/AuthContext';
import { LanguageProvider, useLanguage } from '@/src/context/LanguageContext';
// Side-effect import: initialises i18next with all four language resources.
// Must be imported before any component that calls useTranslation().
import i18n from '@/src/i18n';
// Import type-augmentation so useTranslation() is fully typed everywhere.
import '@/src/i18n/types';
import { cleanAllExpiredStories } from '@/src/features/chat/services/firebaseStoryService';
import { ONESIGNAL_APP_ID } from '@/src/config/onesignal';
import {
  initializeOneSignal,
  loginOneSignal,
  logoutOneSignal,
  registerNotificationOpenedHandler,
} from '@/src/services/pushNotificationService';

SplashScreen.preventAutoHideAsync();

const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      retry: 2,
      staleTime: 30_000,
    },
  },
});

// ─── Auth + Language Guard ────────────────────────────────────────────────────
//
// Navigation rules (evaluated in order):
//   1. While loading (auth or language) → show spinner.
//   2. Language not yet selected + not already on language-select → go there.
//   3. Language selected, no user, not in auth group → go to login.
//   4. Language selected, user present, in auth group → go to home.

function AuthGuard({ children }: { children: React.ReactNode }) {
  const { user, loading: authLoading } = useAuth();
  const { isLanguageSelected, isLoading: langLoading } = useLanguage();
  const segments = useSegments();
  const router = useRouter();

  useEffect(() => {
    if (authLoading || langLoading) return;

    const segs             = segments as string[];
    const inAuthGroup      = segs[0] === 'auth';
    const onLanguageSelect = inAuthGroup && segs[1] === 'language-select';

    if (!isLanguageSelected && !onLanguageSelect) {
      // First launch — must pick a language before anything else.
      router.replace('/auth/language-select');
    } else if (isLanguageSelected && !user && !inAuthGroup) {
      // Language done, not yet logged in.
      router.replace('/auth/login');
    } else if (user && inAuthGroup) {
      // Already authenticated — leave auth screens.
      router.replace('/home');
    }
  }, [user, authLoading, segments, isLanguageSelected, langLoading]);

  // Clean expired stories once on authenticated app start (fire-and-forget)
  useEffect(() => {
    if (user && !authLoading) {
      cleanAllExpiredStories().catch(() => {/* non-critical */});
    }
  }, [user?.uid]);

  // BUG 13 fix: initializeOneSignal is Expo-Go-safe — it checks executionEnvironment
  // internally and is a no-op in Expo Go. Safe to call unconditionally here.
  useEffect(() => {
    initializeOneSignal(ONESIGNAL_APP_ID).catch(() => {/* non-critical */});
  }, []);

  // OneSignal: tapping a background/killed-state push opens the right chat
  useEffect(() => {
    let unsubFn: (() => void) | undefined;
    let cancelled = false;

    registerNotificationOpenedHandler(
      (chatId) => router.push(`/inbox/${chatId}` as any),
      () => router.push('/chat' as any),
    ).then((unsub) => {
      if (cancelled) {
        unsub();
      } else {
        unsubFn = unsub;
      }
    }).catch(() => {/* non-critical — Expo Go safe */});

    return () => {
      cancelled = true;
      unsubFn?.();
    };
  }, []);

  // OneSignal: link to authenticated user
  useEffect(() => {
    if (user?.uid) {
      loginOneSignal(user.uid).catch(() => {/* non-critical */});
    } else if (!authLoading) {
      logoutOneSignal().catch(() => {/* non-critical */});
    }
  }, [user?.uid, authLoading]);

  // BUG 17 fix: Never show an infinite spinner — the loading states already
  // have internal timeouts (AuthContext: 10s, LanguageContext: 6s) so this
  // block will always resolve in a bounded amount of time.
  if (authLoading || langLoading) {
    return (
      <View style={{ flex: 1, backgroundColor: '#07020F', alignItems: 'center', justifyContent: 'center' }}>
        <ActivityIndicator color="#7C3AED" size="large" />
      </View>
    );
  }

  return <>{children}</>;
}

// ─── Navigation Stack ────────────────────────────────────────────────────────

function RootLayoutNav() {
  return (
    <>
      <StatusBar style="light" />
      <Stack
        screenOptions={{
          headerShown: false,
          contentStyle: { backgroundColor: '#07020F' },
          animation: 'fade_from_bottom',
        }}
      >
        <Stack.Screen name="index" />
        {/* Language selection — shown once before login */}
        <Stack.Screen
          name="auth/language-select"
          options={{ animation: 'fade' }}
        />
        <Stack.Screen name="auth/login" />
        <Stack.Screen name="auth/signup" />
        <Stack.Screen name="auth/forgot-password" options={{ animation: 'slide_from_bottom' }} />
        <Stack.Screen name="home/index" />
        <Stack.Screen
          name="voice-room"
          options={{ animation: 'slide_from_bottom', presentation: 'modal' }}
        />
        <Stack.Screen
          name="inbox/[chatId]"
          options={{ animation: 'slide_from_right' }}
        />
        {/* ── User Profile ── */}
        <Stack.Screen
          name="user-profile"
          options={{ animation: 'slide_from_right' }}
        />
        {/* ── Profile sub-screens ── */}
        <Stack.Screen
          name="profile/index"
          options={{ animation: 'slide_from_right' }}
        />
        <Stack.Screen
          name="profile/edit"
          options={{ animation: 'slide_from_right' }}
        />
        <Stack.Screen
          name="profile/notifications"
          options={{ animation: 'slide_from_right' }}
        />
        <Stack.Screen
          name="profile/privacy"
          options={{ animation: 'slide_from_right' }}
        />
        <Stack.Screen
          name="profile/settings"
          options={{ animation: 'slide_from_right' }}
        />
        <Stack.Screen
          name="profile/help"
          options={{ animation: 'slide_from_right' }}
        />
        <Stack.Screen
          name="profile/about"
          options={{ animation: 'slide_from_right' }}
        />
        <Stack.Screen
          name="profile/wallet"
          options={{ animation: 'slide_from_right' }}
        />
        <Stack.Screen name="+not-found" />
      </Stack>
    </>
  );
}

// ─── Root Layout ─────────────────────────────────────────────────────────────

export default function RootLayout() {
  const [fontsLoaded, fontError] = useFonts({
    Inter_400Regular,
    Inter_500Medium,
    Inter_600SemiBold,
    Inter_700Bold,
  });

  useEffect(() => {
    if (fontsLoaded || fontError) {
      SplashScreen.hideAsync().catch(() => {});
    }
  }, [fontsLoaded, fontError]);

  // BUG 17 fix: hard timeout so splash never blocks forever on slow devices
  useEffect(() => {
    const t = setTimeout(() => SplashScreen.hideAsync().catch(() => {}), 3000);
    return () => clearTimeout(t);
  }, []);

  return (
    // I18nextProvider makes the i18n instance available to useTranslation()
    <I18nextProvider i18n={i18n}>
      <LanguageProvider>
        <SafeAreaProvider>
          {/* BUG 18 fix: ErrorBoundary at the root catches all unhandled render
              errors and shows a recovery UI instead of freezing the app. */}
          <ErrorBoundary>
            <AuthProvider>
              <QueryClientProvider client={queryClient}>
                <GestureHandlerRootView style={{ flex: 1 }}>
                  <AuthGuard>
                    <RootLayoutNav />
                  </AuthGuard>
                </GestureHandlerRootView>
              </QueryClientProvider>
            </AuthProvider>
          </ErrorBoundary>
        </SafeAreaProvider>
      </LanguageProvider>
    </I18nextProvider>
  );
}

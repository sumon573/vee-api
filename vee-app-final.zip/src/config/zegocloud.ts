/**
 * ZEGOCLOUD Config — Vee App Voice Rooms
 *
 * ⚠️  Production-এ App Sign backend token দিয়ে replace করুন।
 *     Client-side App Sign শুধু development-এর জন্য।
 */

export const ZEGO_CONFIG = {
  appID: 1932008396,
  appSign: 'c711a7a14e131ccfb53a6c3a1a4ec1f546b6760f16170730e769564dfe0670e1',
};

export function isZegoConfigured(): boolean {
  return ZEGO_CONFIG.appID !== 0 && ZEGO_CONFIG.appSign !== 'YOUR_APP_SIGN';
}

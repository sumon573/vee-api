/**
 * Auth Service — Firebase Auth (Production)
 * Supports: Email/Password, Password Reset
 * Google Sign-In removed.
 */

import {
  createUserWithEmailAndPassword,
  signInWithEmailAndPassword,
  signOut,
  sendPasswordResetEmail,
  updateProfile,
  onAuthStateChanged,
  User,
  AuthError,
} from 'firebase/auth';
import { auth } from '../config/firebase';

export type { User as AuthUser };

// ─── Error Messages (Bengali) ────────────────────────────────────────────────

export function getAuthErrorMessage(error: unknown): string {
  const code = (error as AuthError)?.code ?? '';
  const messages: Record<string, string> = {
    'auth/user-not-found':         'এই email দিয়ে কোনো account নেই।',
    'auth/wrong-password':         'Password ভুল। আবার চেষ্টা করুন।',
    'auth/invalid-credential':     'Email অথবা Password ভুল।',
    'auth/email-already-in-use':   'এই email দিয়ে ইতোমধ্যে account আছে।',
    'auth/weak-password':          'Password কমপক্ষে ৬ অক্ষরের হতে হবে।',
    'auth/invalid-email':          'সঠিক email ঠিকানা দিন।',
    'auth/too-many-requests':      'অনেকবার চেষ্টা করা হয়েছে। কিছুক্ষণ পরে চেষ্টা করুন।',
    'auth/network-request-failed': 'Internet connection নেই। চেক করুন।',
    'auth/user-disabled':          'এই account টি disabled করা হয়েছে।',
    'auth/operation-not-allowed':  'এই login পদ্ধতি এখন চালু নেই।',
    'auth/requires-recent-login':  'এই কাজের জন্য আবার login করুন।',
  };
  return messages[code] ?? 'কিছু একটা সমস্যা হয়েছে। আবার চেষ্টা করুন।';
}

// ─── Core Auth Functions ─────────────────────────────────────────────────────

/** Sign in with email and password */
export async function login(email: string, password: string): Promise<User> {
  const { user } = await signInWithEmailAndPassword(auth, email.trim(), password);
  return user;
}

/** Create new account with email, password, and display name */
export async function signUp(
  email: string,
  password: string,
  name: string,
): Promise<User> {
  const { user } = await createUserWithEmailAndPassword(auth, email.trim(), password);
  await updateProfile(user, { displayName: name.trim() });
  return user;
}

/** Sign out the current user */
export async function logout(): Promise<void> {
  await signOut(auth);
}

/** Send password reset email */
export async function resetPassword(email: string): Promise<void> {
  await sendPasswordResetEmail(auth, email.trim());
}

/** Get currently authenticated user (may be null) */
export function getCurrentUser(): User | null {
  return auth.currentUser;
}

/** Subscribe to auth state changes. Returns unsubscribe function. */
export function onUserStateChanged(
  callback: (user: User | null) => void,
): () => void {
  return onAuthStateChanged(auth, callback);
}

/** Update display name and/or photo URL */
export async function updateUserProfile(
  name?: string,
  photoURL?: string,
): Promise<void> {
  const user = auth.currentUser;
  if (!user) throw new Error('No authenticated user.');
  await updateProfile(user, {
    ...(name && { displayName: name }),
    ...(photoURL && { photoURL }),
  });
}

/**
 * Notify Service — client → API server → OneSignal
 *
 * Fire-and-forget push notification trigger. The API server
 * (https://vee-api.onrender.com) holds the OneSignal REST API key and
 * forwards the request. Recipients are targeted by their Firebase uid,
 * which is set as the OneSignal "external user id" via `OneSignal.login(uid)`
 * on app start (see `src/services/pushNotificationService.ts`).
 *
 * Never throws — a failed push should never block the underlying action.
 */

const API_BASE = 'https://vee-api.onrender.com';

/**
 * Send a push notification to a single recipient.
 * @param targetUid Firebase uid of the recipient.
 * @param title     Notification title (e.g. sender's name).
 * @param message   Notification body.
 * @param data      Optional payload delivered as `additionalData` on the client
 *                  (e.g. `{ chatId }` so tapping opens the right chat).
 */
export function sendPushNotification(
  targetUid: string,
  title: string,
  message: string,
  data?: Record<string, unknown>,
): void {
  if (!targetUid || !title || !message) return;

  fetch(`${API_BASE}/api/notifications/send`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ externalUserId: targetUid, title, message, data }),
  }).catch((err) => {
    console.warn('[Notify] push failed:', err);
  });
}

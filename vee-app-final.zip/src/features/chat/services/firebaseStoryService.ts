/**
 * Firebase Story Service — ধাপ ৫
 * Stories: 24 ঘণ্টা পর auto-expire।
 *
 * DB Structure:
 *   stories/{uid}/{storyId}  →  Story object
 */

import {
  ref, push, set, update, remove,
  onValue, get, serverTimestamp, runTransaction,
} from 'firebase/database';
import { database } from '@/src/config/firebase';
import { Story, UserStories } from '../types';

// ─── Publish ─────────────────────────────────────────────────────────────────

export interface PublishPayload {
  type: 'text' | 'image';
  content: string;                 // text string or Cloudinary URL
  bgGradient: [string, string];
  mentions: string[];
  cloudinaryId?: string;
  textColor?: string;
}

export async function publishStory(
  uid: string,
  userName: string,
  userAvatar: string | undefined,
  payload: PublishPayload,
): Promise<string> {
  const storiesRef = ref(database, `stories/${uid}`);
  const newRef = push(storiesRef);

  const now = Date.now();
  const story: Omit<Story, 'id' | 'createdAt'> & { createdAt: object } = {
    userId: uid,
    userName,
    ...(userAvatar ? { userAvatar } : {}),
    type: payload.type,
    content: payload.content,
    bgGradient: payload.bgGradient,
    textColor: payload.textColor ?? '#FFFFFF',
    mentions: payload.mentions,
    createdAt: serverTimestamp() as object,
    expiresAt: now + 24 * 60 * 60 * 1000,   // 24h
    viewCount: 0,
    reactions: {},
    comments: [],
    ...(payload.cloudinaryId ? { cloudinaryId: payload.cloudinaryId } : {}),
  };

  await set(newRef, story);

  // Keep a summary in users/{uid} for the story bar avatar ring
  await update(ref(database, `users/${uid}`), { hasActiveStory: true });

  return newRef.key!;
}

// ─── Subscribe ────────────────────────────────────────────────────────────────

/** Real-time subscription to ALL active (non-expired) stories. */
export function subscribeAllStories(
  callback: (groups: UserStories[]) => void,
): () => void {
  const storiesRef = ref(database, 'stories');
  return onValue(storiesRef, (snap) => {
    if (!snap.exists()) { callback([]); return; }

    const now = Date.now();
    const groups: UserStories[] = [];

    snap.forEach((userSnap) => {
      const uid = userSnap.key!;
      const stories: Story[] = [];

      userSnap.forEach((storySnap) => {
        const v = storySnap.val() as Record<string, unknown>;
        const expiresAt = (v.expiresAt as number) ?? 0;
        if (expiresAt < now) return; // expired — skip

        stories.push({
          id: storySnap.key!,
          userId: v.userId as string,
          userName: v.userName as string,
          userAvatar: v.userAvatar as string | undefined,
          type: (v.type as 'text' | 'image') ?? 'text',
          content: (v.content as string) ?? '',
          bgGradient: (v.bgGradient as [string, string]) ?? ['#7C3AED', '#A855F7'],
          textColor: (v.textColor as string) ?? '#FFFFFF',
          mentions: (v.mentions as string[]) ?? [],
          createdAt: (v.createdAt as number) ?? Date.now(),
          expiresAt,
          viewCount: (v.viewCount as number) ?? 0,
          reactions: (v.reactions as Record<string, string>) ?? {},
          comments: [],
          cloudinaryId: v.cloudinaryId as string | undefined,
        });
      });

      if (stories.length > 0) {
        // Newest story first within each user's group
        stories.sort((a, b) => b.createdAt - a.createdAt);
        groups.push({
          userId: uid,
          userName: stories[0].userName,
          userAvatar: stories[0].userAvatar,
          stories,
          allSeen: false, // seen state: per-device, not tracked in Firebase for now
        });
      }
    });

    // Sort: users with most recent story first
    groups.sort((a, b) =>
      (b.stories[0]?.createdAt ?? 0) - (a.stories[0]?.createdAt ?? 0),
    );

    callback(groups);
  });
}

/** Subscribe to a single user's stories. */
export function subscribeMyStories(
  uid: string,
  callback: (stories: Story[]) => void,
): () => void {
  const myRef = ref(database, `stories/${uid}`);
  return onValue(myRef, (snap) => {
    if (!snap.exists()) { callback([]); return; }
    const now = Date.now();
    const stories: Story[] = [];
    snap.forEach((s) => {
      const v = s.val() as Record<string, unknown>;
      const expiresAt = (v.expiresAt as number) ?? 0;
      if (expiresAt < now) return;
      stories.push({
        id: s.key!,
        userId: v.userId as string,
        userName: v.userName as string,
        userAvatar: v.userAvatar as string | undefined,
        type: (v.type as 'text' | 'image') ?? 'text',
        content: (v.content as string) ?? '',
        bgGradient: (v.bgGradient as [string, string]) ?? ['#7C3AED', '#A855F7'],
        textColor: (v.textColor as string) ?? '#FFFFFF',
        mentions: (v.mentions as string[]) ?? [],
        createdAt: (v.createdAt as number) ?? Date.now(),
        expiresAt,
        viewCount: (v.viewCount as number) ?? 0,
        reactions: (v.reactions as Record<string, string>) ?? {},
        comments: [],
        cloudinaryId: v.cloudinaryId as string | undefined,
      });
    });
    stories.sort((a, b) => b.createdAt - a.createdAt);
    callback(stories);
  });
}

// ─── View ─────────────────────────────────────────────────────────────────────

/** Increment view count (fire-and-forget). */
export function recordStoryView(authorUid: string, storyId: string): void {
  // Transaction avoids lost increments when multiple viewers open the story
  // around the same time (plain get-then-set can drop concurrent +1s).
  runTransaction(
    ref(database, `stories/${authorUid}/${storyId}/viewCount`),
    (current) => (typeof current === 'number' ? current : 0) + 1,
  ).catch(() => {/* non-critical */});
}

// ─── React ────────────────────────────────────────────────────────────────────

/** Toggle reaction emoji on a story. */
export async function reactToStory(
  authorUid: string,
  storyId: string,
  reactorUid: string,
  emoji: string,
): Promise<void> {
  const reactionRef = ref(database, `stories/${authorUid}/${storyId}/reactions/${reactorUid}`);
  const snap = await get(reactionRef);
  if (snap.exists() && snap.val() === emoji) {
    await set(reactionRef, null); // toggle off
  } else {
    await set(reactionRef, emoji);
  }
}

// ─── Delete ───────────────────────────────────────────────────────────────────

/** Delete own story. */
export async function deleteStory(
  uid: string,
  storyId: string,
): Promise<void> {
  await remove(ref(database, `stories/${uid}/${storyId}`));
  // Clear hasActiveStory flag if no stories left
  const remaining = await get(ref(database, `stories/${uid}`));
  if (!remaining.exists()) {
    await update(ref(database, `users/${uid}`), { hasActiveStory: false });
  }
}

// ─── Story Seen State (Firebase-persisted) ────────────────────────────────────

/**
 * Mark a user's stories as seen by the viewer.
 * Stored in: storySeen/{viewerUid}/{authorUid} → timestamp
 */
export async function markStorySeen(viewerUid: string, authorUid: string): Promise<void> {
  await set(ref(database, `storySeen/${viewerUid}/${authorUid}`), Date.now());
}

/**
 * Subscribe to which story authors have been seen by this viewer.
 * Returns a Set of authorUids that the viewer has already seen.
 */
export function subscribeStorySeen(
  viewerUid: string,
  callback: (seenUids: Set<string>) => void,
): () => void {
  return onValue(ref(database, `storySeen/${viewerUid}`), (snap) => {
    const seenUids = new Set<string>();
    if (snap.exists()) {
      snap.forEach((child) => {
        if (child.key) seenUids.add(child.key);
      });
    }
    callback(seenUids);
  });
}

// ─── Cleanup (call once on app start or via Cloud Function) ──────────────────

/**
 * Remove expired stories for a given user (client-side cleanup).
 * Production-এ Firebase Cloud Function দিয়ে করা উচিত।
 */
export async function cleanExpiredStories(uid: string): Promise<void> {
  const snap = await get(ref(database, `stories/${uid}`));
  if (!snap.exists()) return;
  const now = Date.now();
  const deletions: Promise<void>[] = [];
  snap.forEach((s) => {
    const v = s.val() as { expiresAt?: number };
    if ((v.expiresAt ?? 0) < now) {
      deletions.push(remove(ref(database, `stories/${uid}/${s.key}`)));
    }
  });
  await Promise.all(deletions);
}

/**
 * Remove expired stories for ALL users (call once on app launch).
 * Production এ Firebase Cloud Function দিয়ে করা উচিত।
 */
export async function cleanAllExpiredStories(): Promise<void> {
  try {
    const snap = await get(ref(database, 'stories'));
    if (!snap.exists()) return;
    const now = Date.now();
    const deletions: Promise<void>[] = [];
    snap.forEach((userSnap) => {
      const uid = userSnap.key!;
      let hasActive = false;
      userSnap.forEach((storySnap) => {
        const v = storySnap.val() as { expiresAt?: number };
        if ((v.expiresAt ?? 0) < now) {
          deletions.push(remove(ref(database, `stories/${uid}/${storySnap.key}`)));
        } else {
          hasActive = true;
        }
      });
      // If no active stories remain, clear the hasActiveStory flag
      if (!hasActive) {
        deletions.push(
          update(ref(database, `users/${uid}`), { hasActiveStory: false }) as Promise<void>,
        );
      }
    });
    await Promise.all(deletions);
  } catch {
    // Non-critical — silently fail
  }
}

/**
 * useStories — ধাপ ৫ + Story Seen State (Firebase-persisted)
 * Firebase real-time stories subscription + publish.
 * app/chat/index.tsx এ ব্যবহার করা হয়।
 */

import { useState, useEffect, useCallback, useRef } from 'react';
import { useAuth } from '@/src/context/AuthContext';
import { UserStories, Story } from '../types';
import {
  subscribeAllStories,
  subscribeMyStories,
  publishStory,
  recordStoryView,
  reactToStory,
  deleteStory,
  cleanExpiredStories,
  markStorySeen,
  subscribeStorySeen,
  PublishPayload,
} from '../services/firebaseStoryService';

export interface UseStoriesResult {
  stories: UserStories[];          // all users' stories (for StoryBar)
  myStories: Story[];              // current user's own stories
  loading: boolean;
  publish: (payload: PublishPayload) => Promise<void>;
  recordView: (authorUid: string, storyId: string) => void;
  react: (authorUid: string, storyId: string, emoji: string) => Promise<void>;
  remove: (storyId: string) => Promise<void>;
  markGroupSeen: (userId: string) => void;
}

export function useStories(): UseStoriesResult {
  const { user } = useAuth();
  const [stories, setStories] = useState<UserStories[]>([]);
  const [myStories, setMyStories] = useState<Story[]>([]);
  const [loading, setLoading] = useState(true);
  // Firebase-persisted seen UIDs
  const seenRef = useRef<Set<string>>(new Set());

  // Subscribe to Firebase-persisted seen state
  useEffect(() => {
    if (!user?.uid) return;
    const unsub = subscribeStorySeen(user.uid, (seenUids) => {
      seenRef.current = seenUids;
      // Update allSeen for already-loaded stories
      setStories((prev) => prev.map((g) => ({
        ...g,
        allSeen: seenUids.has(g.userId),
      })));
    });
    return unsub;
  }, [user?.uid]);

  // Subscribe to all stories
  useEffect(() => {
    const unsub = subscribeAllStories((groups) => {
      // Merge Firebase seen state from ref
      setStories(groups.map((g) => ({
        ...g,
        allSeen: seenRef.current.has(g.userId),
      })));
      setLoading(false);
    });
    return unsub;
  }, []);

  // Subscribe to own stories + clean expired on mount
  useEffect(() => {
    if (!user?.uid) return;
    cleanExpiredStories(user.uid).catch(() => {});
    const unsub = subscribeMyStories(user.uid, setMyStories);
    return unsub;
  }, [user?.uid]);

  const publish = useCallback(async (payload: PublishPayload) => {
    if (!user?.uid) throw new Error('Not authenticated');
    await publishStory(
      user.uid,
      user.displayName ?? 'You',
      user.photoURL ?? undefined,
      payload,
    );
  }, [user]);

  const recordView = useCallback((authorUid: string, storyId: string) => {
    recordStoryView(authorUid, storyId);
  }, []);

  const react = useCallback(async (authorUid: string, storyId: string, emoji: string) => {
    if (!user?.uid) return;
    await reactToStory(authorUid, storyId, user.uid, emoji);
  }, [user?.uid]);

  const remove = useCallback(async (storyId: string) => {
    if (!user?.uid) return;
    await deleteStory(user.uid, storyId);
  }, [user?.uid]);

  /** Mark a story group as seen — saves to Firebase so it persists across app restarts */
  const markGroupSeen = useCallback((userId: string) => {
    if (!user?.uid) return;
    seenRef.current.add(userId);
    setStories((prev) => prev.map((g) =>
      g.userId === userId ? { ...g, allSeen: true } : g,
    ));
    // Persist to Firebase (fire-and-forget)
    markStorySeen(user.uid, userId).catch(() => {});
  }, [user?.uid]);

  return { stories, myStories, loading, publish, recordView, react, remove, markGroupSeen };
}

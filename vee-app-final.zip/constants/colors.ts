const colors = {
  light: {
    // Legacy
    text: '#FFFFFF',
    tint: '#7C3AED',

    background: '#07020F',
    foreground: '#FFFFFF',

    card: '#121026',
    cardForeground: '#FFFFFF',

    primary: '#7C3AED',
    primaryForeground: '#FFFFFF',

    secondary: '#1A1535',
    secondaryForeground: '#B8A6D9',

    muted: '#1E1830',
    mutedForeground: '#6B5E8A',

    accent: '#A855F7',
    accentForeground: '#FFFFFF',

    destructive: '#EF4444',
    destructiveForeground: '#FFFFFF',

    border: '#2A2542',
    input: '#2A2542',

    // Vee-specific
    glow: '#8B5CF6',
    surface: 'rgba(255,255,255,0.045)',
    inputBg: 'rgba(139,92,246,0.07)',
    google: '#DB4437',
    live: '#EF4444',
    mic: '#22C55E',
    success: '#22C55E',
    warning: '#F59E0B',
    textSecondary: '#B8A6D9',
    textMuted: '#6B5E8A',
  },

  radius: 16,
};

export default colors;
